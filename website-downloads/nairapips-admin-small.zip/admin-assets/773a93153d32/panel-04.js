
document.addEventListener("DOMContentLoaded",()=>{setTimeout(()=>{try{npInstallStaffPermissionGuard();npApplyNavigationPermissions();npApplyModuleWorkMode()}catch(e){console.error("Staff permission mode setup failed",e)}},700)});
