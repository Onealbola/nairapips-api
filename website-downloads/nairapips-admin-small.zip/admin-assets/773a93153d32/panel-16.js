
window.openFundedCycleReturn=function(){toast("Same-MT5 payout cycles are retired. A PAID payout requires a fresh Funded MT5.","err")};window.confirmFundedCycleReturn=window.openFundedCycleReturn;
