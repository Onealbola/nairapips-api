"""Read only local drawdown journals; never connect to MT5 or stop any process."""
from pathlib import Path
import os,json,zipfile
IDS=['0d1a0079-ad4b-41ac-b656-9763f2119a9e','7ac1c173-14ba-408c-992c-f96ac6ca9fc0','e278919a-83a9-4da9-be69-8e9ab1fc7010','a1291358-cad0-4b37-993c-5e6acb59c15f','72b72c9e-8426-4f6d-8f62-1b338434c541','b43b62ef-9a1e-428d-9b45-3bca0ec70980','0b367504-96c9-4220-9a0e-eb414e975dc9']
SAFE={'rules_hash','highest_equity','lowest_equity','drawdown_floor','worst_used_percent','drawdown_percent','used_percent','breached','first_breach','observed_at','last_observed_at','daily_date','daily_loss','daily_realised','daily_drawdown','daily_floor','daily_allowance','version','account_id'}
home=Path(os.environ.get('USERPROFILE') or Path.home())
roots=[]
for parent in (home/'Documents',home/'Downloads'):
 if parent.is_dir():
  for child in parent.iterdir():
   if child.is_dir() and child.name.lower().startswith('nairapips'):
    roots.append(child)
report={'purpose':'Exact-account drawdown history diagnostic; no broker connection or trading changes','found':[],'missing':list(IDS),'errors':[]}
for root in roots:
 for name in ('equity_dd_state','package_dd_state'):
  folder=root/name
  if not folder.is_dir():continue
  for aid in IDS:
   path=folder/(aid+'.json')
   if not path.is_file():continue
   try:
    if path.stat().st_size>65536:raise ValueError('Journal exceeds expected bound')
    state=json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(state,dict):raise ValueError('Invalid journal format')
    report['found'].append({'account_id':aid,'journal_directory':str(folder),'state':{k:v for k,v in state.items() if k in SAFE}})
    if aid in report['missing']:report['missing'].remove(aid)
   except Exception as exc:report['errors'].append({'account_id':aid,'error':type(exc).__name__})
target=home/'Desktop'
if not target.is_dir():target=Path(__file__).resolve().parent
out=target/'NairaPips-Rule-History-Report.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('rule-history-report.json',json.dumps(report,indent=2))
print('No MT5 process was stopped. No broker connection was opened. No risk state was changed.')
print('Saved history files found:',len(report['found']))
print('Send this report back for the exact-account repair:',str(out))
