@echo off
python "%~dp0CHECK_RISK_HISTORY.py"
pause
